package br.com.fiap.entity;


public enum TipoSanguineo {
	O_POSITIVO, O_NEGATIVO, A_POSITIVO, A_NEGATIVO, B_POSITIVO, B_NEGATIVO, AB_POSITIVO, AB_NEGATIVO
}
